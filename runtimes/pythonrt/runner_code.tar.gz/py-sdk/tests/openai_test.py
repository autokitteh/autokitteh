# Smoke test, fill with content


def test_smoke():
    from autokitteh import openai  # noqa: F401
