# Smoke test, fill with content


def test_smoke():
    from autokitteh import salesforce  # noqa: F401
