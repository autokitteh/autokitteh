# Smoke test, fill with content


def test_smoke():
    from autokitteh import height  # noqa: F401
