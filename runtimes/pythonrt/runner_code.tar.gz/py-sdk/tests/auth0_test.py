# Smoke test, fill with content


def test_smoke():
    from autokitteh import auth0  # noqa: F401
