# Smoke test, fill with content


def test_smoke():
    import autokitteh  # noqa: F401
