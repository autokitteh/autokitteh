# This file must be named hlog.py (or any name that don't collides with files in runner)
import logging


def info(msg):
    logging.info(msg)
