def on_event(event):
    print("EVENT:", event)
